"use client"

import { useEffect, useRef, useState } from "react"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { MapPin } from "lucide-react"

// This would normally be in an environment variable
// For this example, we're using a temporary token
mapboxgl.accessToken = "pk.eyJ1IjoibmlsYXZhbnNqIiwiYSI6ImNtOWJrNDQzczA5dTAya3F3YWd2Y3FjM2UifQ.FlSPtvEJVBpFZsv5xFw1SA"

interface WaterSourceMapProps {
  sources: any[]
  selectedSource: any | null
  onSourceClick: (source: any) => void
}

export function WaterSourceMap({ sources, selectedSource, onSourceClick }: WaterSourceMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const markersRef = useRef<{ [key: string]: mapboxgl.Marker }>({})
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null)
  const [locationError, setLocationError] = useState<string | null>(null)
  const { toast } = useToast()

  // Initialize map with default location (center of India)
  useEffect(() => {
    if (map.current) return // Map already initialized

    if (mapContainer.current) {
      // Default center on Bangalore, India
      const defaultCenter: [number, number] = [77.5946, 12.9716]

      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: "mapbox://styles/mapbox/streets-v12",
        center: defaultCenter,
        zoom: 11,
      })

      map.current.addControl(new mapboxgl.NavigationControl(), "top-right")
      map.current.addControl(new mapboxgl.FullscreenControl(), "top-right")

      // Add scale control
      map.current.addControl(new mapboxgl.ScaleControl(), "bottom-left")
    }

    return () => {
      if (map.current) {
        map.current.remove()
        map.current = null
      }
    }
  }, [])

  // Function to try getting user location
  const getUserLocation = () => {
    setLocationError(null)

    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser")
      toast({
        title: "Location Not Available",
        description: "Geolocation is not supported by your browser.",
        variant: "destructive",
      })
      return
    }

    const options = {
      enableHighAccuracy: false,
      timeout: 5000,
      maximumAge: 0,
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { longitude, latitude } = position.coords
        setUserLocation([longitude, latitude])

        if (map.current) {
          map.current.flyTo({
            center: [longitude, latitude],
            zoom: 14,
            essential: true,
          })

          // Add user location marker
          new mapboxgl.Marker({ color: "#FF0000" })
            .setLngLat([longitude, latitude])
            .addTo(map.current)
            .setPopup(new mapboxgl.Popup().setHTML("<strong>Your Location</strong>"))

          toast({
            title: "Location Found",
            description: "Map centered to your current location.",
          })
        }
      },
      (error) => {
        console.error("Error getting location:", error)
        let errorMessage = "Unable to retrieve your location."

        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location access was denied. Please enable location services to find water sources near you."
            break
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information is unavailable."
            break
          case error.TIMEOUT:
            errorMessage = "The request to get your location timed out."
            break
        }

        setLocationError(errorMessage)
        toast({
          title: "Location Access Failed",
          description: errorMessage,
          variant: "destructive",
        })
      },
      options,
    )
  }

  // Update markers when sources change
  useEffect(() => {
    if (!map.current) return

    // Clear existing markers
    Object.values(markersRef.current).forEach((marker) => marker.remove())
    markersRef.current = {}

    // Add markers for each source
    sources.forEach((source) => {
      if (!source.latitude || !source.longitude) return

      const safetyColor = getSafetyColor(source.safety_score)

      const el = document.createElement("div")
      el.className = "water-source-marker"
      el.style.width = "30px"
      el.style.height = "30px"
      el.style.borderRadius = "50%"
      el.style.backgroundColor = safetyColor
      el.style.border = "2px solid white"
      el.style.boxShadow = "0 2px 4px rgba(0,0,0,0.3)"
      el.style.cursor = "pointer"

      const marker = new mapboxgl.Marker(el)
        .setLngLat([source.longitude, source.latitude])
        .setPopup(
          new mapboxgl.Popup({ offset: 25 }).setHTML(`
              <strong>${source.name}</strong><br>
              <span>${source.source_type}</span><br>
              <span>Safety: ${source.safety_score}%</span>
            `),
        )
        .addTo(map.current)

      marker.getElement().addEventListener("click", () => {
        onSourceClick(source)
      })

      markersRef.current[source.id] = marker
    })

    // If we have sources but no user location, center the map on the first source
    if (sources.length > 0 && !userLocation && map.current) {
      const firstSource = sources[0]
      if (firstSource.latitude && firstSource.longitude) {
        map.current.flyTo({
          center: [firstSource.longitude, firstSource.latitude],
          zoom: 11,
          essential: true,
        })
      }
    }
  }, [sources, onSourceClick, userLocation])

  // Update selected source
  useEffect(() => {
    if (!map.current || !selectedSource) return

    const marker = markersRef.current[selectedSource.id]
    if (marker) {
      marker.togglePopup()

      map.current.flyTo({
        center: [selectedSource.longitude, selectedSource.latitude],
        zoom: 15,
        essential: true,
      })
    }
  }, [selectedSource])

  const getSafetyColor = (score: number) => {
    if (score >= 80) return "#10B981" // Green
    if (score >= 60) return "#22C55E" // Light green
    if (score >= 40) return "#F59E0B" // Yellow
    if (score >= 20) return "#F97316" // Orange
    return "#EF4444" // Red
  }

  return (
    <div className="relative">
      <div ref={mapContainer} className="w-full h-[600px]" />
      <div className="absolute top-4 left-4 z-10">
        <Button
          onClick={getUserLocation}
          className="flex items-center gap-2 bg-white text-black hover:bg-gray-100 shadow-md"
          size="sm"
        >
          <MapPin size={16} />
          Find My Location
        </Button>
        {locationError && (
          <div className="mt-2 p-2 bg-white/90 rounded text-xs text-red-600 max-w-[250px] shadow">{locationError}</div>
        )}
      </div>
      {sources.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/5">
          <div className="bg-white p-4 rounded-md shadow-lg">
            <p className="text-center">No water sources found in this area.</p>
          </div>
        </div>
      )}
    </div>
  )
}
