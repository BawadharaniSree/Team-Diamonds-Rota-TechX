"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Search } from "lucide-react"
import { WaterSourceMap } from "@/components/public/water-source-map"
import { WaterSourceInfo } from "@/components/public/water-source-info"
import { getSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/components/ui/use-toast"

export default function MapPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSource, setSelectedSource] = useState<any>(null)
  const [waterSources, setWaterSources] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [filters, setFilters] = useState({
    sourceTypes: {
      lake: true,
      tank: true,
      borewell: true,
      river: true,
      tap: true,
    },
    safetyScore: [0, 100],
    isPaid: null as boolean | null,
    distance: 10, // km
  })
  const { toast } = useToast()
  const supabase = getSupabaseClient()

  useEffect(() => {
    fetchWaterSources()
  }, [])

  const fetchWaterSources = async () => {
    setIsLoading(true)
    try {
      const { data, error } = await supabase.from("public_water_sources").select("*")

      if (error) {
        throw error
      }

      setWaterSources(data || [])
    } catch (error) {
      console.error("Error fetching water sources:", error)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load water sources. Please try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSourceClick = async (source: any) => {
    try {
      // Fetch additional details about the source
      const { data: qualityData, error: qualityError } = await supabase
        .from("public_water_quality")
        .select("*")
        .eq("source_id", source.id)
        .order("measured_at", { ascending: false })
        .limit(1)
        .single()

      if (qualityError && qualityError.code !== "PGRST116") {
        console.error("Error fetching quality data:", qualityError)
      }

      // Fetch source images
      const { data: imageData, error: imageError } = await supabase
        .from("public_water_source_images")
        .select("*")
        .eq("source_id", source.id)
        .limit(5)

      if (imageError) {
        console.error("Error fetching image data:", imageError)
      }

      setSelectedSource({
        ...source,
        quality: qualityData || null,
        images: imageData || [],
      })
    } catch (error) {
      console.error("Error fetching source details:", error)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load source details. Please try again.",
      })
    }
  }

  const handleFilterChange = (filterType: string, value: any) => {
    setFilters((prev) => {
      if (filterType === "sourceTypes") {
        return {
          ...prev,
          sourceTypes: {
            ...prev.sourceTypes,
            [value]: !prev.sourceTypes[value as keyof typeof prev.sourceTypes],
          },
        }
      } else if (filterType === "safetyScore") {
        return { ...prev, safetyScore: value }
      } else if (filterType === "isPaid") {
        return { ...prev, isPaid: value }
      } else if (filterType === "distance") {
        return { ...prev, distance: value }
      }
      return prev
    })
  }

  const filteredSources = waterSources.filter((source) => {
    // Filter by source type
    if (!filters.sourceTypes[source.source_type as keyof typeof filters.sourceTypes]) {
      return false
    }

    // Filter by safety score
    if (source.safety_score < filters.safetyScore[0] || source.safety_score > filters.safetyScore[1]) {
      return false
    }

    // Filter by paid/free
    if (filters.isPaid !== null && source.is_paid !== filters.isPaid) {
      return false
    }

    // Filter by search query
    if (searchQuery && !source.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false
    }

    return true
  })

  return (
    <div className="flex flex-col min-h-screen">
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-3xl font-bold mb-6">Find Water Sources</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sidebar with filters */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search water sources..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">Filters</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setFilters({
                          sourceTypes: {
                            lake: true,
                            tank: true,
                            borewell: true,
                            river: true,
                            tap: true,
                          },
                          safetyScore: [0, 100],
                          isPaid: null,
                          distance: 10,
                        })
                        setSearchQuery("")
                      }}
                    >
                      Reset
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium mb-2">Source Type</h4>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="filter-lake"
                            checked={filters.sourceTypes.lake}
                            onCheckedChange={() => handleFilterChange("sourceTypes", "lake")}
                          />
                          <Label htmlFor="filter-lake">Lake</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="filter-tank"
                            checked={filters.sourceTypes.tank}
                            onCheckedChange={() => handleFilterChange("sourceTypes", "tank")}
                          />
                          <Label htmlFor="filter-tank">Tank</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="filter-borewell"
                            checked={filters.sourceTypes.borewell}
                            onCheckedChange={() => handleFilterChange("sourceTypes", "borewell")}
                          />
                          <Label htmlFor="filter-borewell">Borewell</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="filter-river"
                            checked={filters.sourceTypes.river}
                            onCheckedChange={() => handleFilterChange("sourceTypes", "river")}
                          />
                          <Label htmlFor="filter-river">River</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="filter-tap"
                            checked={filters.sourceTypes.tap}
                            onCheckedChange={() => handleFilterChange("sourceTypes", "tap")}
                          />
                          <Label htmlFor="filter-tap">Tap</Label>
                        </div>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium">Safety Score</h4>
                        <span className="text-xs text-muted-foreground">
                          {filters.safetyScore[0]} - {filters.safetyScore[1]}
                        </span>
                      </div>
                      <Slider
                        defaultValue={[0, 100]}
                        max={100}
                        step={1}
                        value={filters.safetyScore}
                        onValueChange={(value) => handleFilterChange("safetyScore", value)}
                        className="my-4"
                      />
                    </div>

                    <div>
                      <h4 className="text-sm font-medium mb-2">Cost</h4>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant={filters.isPaid === false ? "default" : "outline"}
                          size="sm"
                          onClick={() => handleFilterChange("isPaid", false)}
                        >
                          Free
                        </Button>
                        <Button
                          variant={filters.isPaid === true ? "default" : "outline"}
                          size="sm"
                          onClick={() => handleFilterChange("isPaid", true)}
                        >
                          Paid
                        </Button>
                        <Button
                          variant={filters.isPaid === null ? "default" : "outline"}
                          size="sm"
                          onClick={() => handleFilterChange("isPaid", null)}
                        >
                          All
                        </Button>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium">Distance (km)</h4>
                        <span className="text-xs text-muted-foreground">{filters.distance} km</span>
                      </div>
                      <Slider
                        defaultValue={[10]}
                        max={50}
                        step={1}
                        value={[filters.distance]}
                        onValueChange={(value) => handleFilterChange("distance", value[0])}
                        className="my-4"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium mb-2">Results</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Found {filteredSources.length} water sources matching your criteria
                </p>

                <div className="space-y-2 max-h-[400px] overflow-y-auto">
                  {isLoading ? (
                    <div className="text-center py-4">Loading sources...</div>
                  ) : filteredSources.length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground">No sources found</div>
                  ) : (
                    filteredSources.map((source) => (
                      <div
                        key={source.id}
                        className={`p-3 rounded-md cursor-pointer transition-colors ${
                          selectedSource?.id === source.id
                            ? "bg-blue-100 dark:bg-blue-900/30"
                            : "hover:bg-slate-100 dark:hover:bg-slate-800"
                        }`}
                        onClick={() => handleSourceClick(source)}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-medium">{source.name}</h4>
                            <p className="text-xs text-muted-foreground">{source.source_type}</p>
                          </div>
                          <Badge
                            variant={
                              source.safety_score > 70
                                ? "success"
                                : source.safety_score > 40
                                  ? "warning"
                                  : "destructive"
                            }
                          >
                            {source.safety_score}%
                          </Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Map and source info */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <WaterSourceMap
                  sources={filteredSources}
                  selectedSource={selectedSource}
                  onSourceClick={handleSourceClick}
                />
              </CardContent>
            </Card>

            {selectedSource && <WaterSourceInfo source={selectedSource} onClose={() => setSelectedSource(null)} />}
          </div>
        </div>
      </div>
    </div>
  )
}
