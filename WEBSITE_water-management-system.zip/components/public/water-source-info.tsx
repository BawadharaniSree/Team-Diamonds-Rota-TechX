"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { AlertTriangle, Clock, Droplet, MapPin, ThumbsUp, Share2, Flag, X } from "lucide-react"
import Link from "next/link"

interface WaterSourceInfoProps {
  source: any
  onClose: () => void
}

export function WaterSourceInfo({ source, onClose }: WaterSourceInfoProps) {
  const [activeTab, setActiveTab] = useState("overview")

  const getSafetyBadge = (score: number) => {
    if (score >= 80) {
      return <Badge className="bg-green-500">Safe</Badge>
    } else if (score >= 60) {
      return <Badge className="bg-yellow-500">Moderate</Badge>
    } else if (score >= 40) {
      return (
        <Badge variant="outline" className="border-orange-500 text-orange-500">
          Caution
        </Badge>
      )
    } else {
      return <Badge variant="destructive">Unsafe</Badge>
    }
  }

  const getQualityIndicator = (name: string, value: any, unit: string, goodRange: [number, number]) => {
    let status = "neutral"
    let statusText = "Neutral"

    if (typeof value === "number") {
      if (value >= goodRange[0] && value <= goodRange[1]) {
        status = "good"
        statusText = "Good"
      } else if (value < goodRange[0] - goodRange[0] * 0.2 || value > goodRange[1] + goodRange[1] * 0.2) {
        status = "bad"
        statusText = "Poor"
      } else {
        status = "moderate"
        statusText = "Moderate"
      }
    }

    return (
      <div className="flex items-center justify-between p-2 border rounded-md">
        <div>
          <p className="text-sm font-medium">{name}</p>
          <p className="text-xs text-muted-foreground">
            {value !== null && value !== undefined ? `${value} ${unit}` : "Not measured"}
          </p>
        </div>
        <Badge
          variant="outline"
          className={`
            ${status === "good" ? "border-green-500 text-green-500" : ""}
            ${status === "moderate" ? "border-yellow-500 text-yellow-500" : ""}
            ${status === "bad" ? "border-red-500 text-red-500" : ""}
            ${status === "neutral" ? "border-gray-500 text-gray-500" : ""}
          `}
        >
          {statusText}
        </Badge>
      </div>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div>
          <CardTitle className="text-xl">{source.name}</CardTitle>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline">{source.source_type}</Badge>
            {getSafetyBadge(source.safety_score)}
            <Badge
              variant="outline"
              className={source.is_paid ? "border-amber-500 text-amber-500" : "border-green-500 text-green-500"}
            >
              {source.is_paid ? "Paid" : "Free"}
            </Badge>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>

      <CardContent className="p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="quality">Quality</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="aspect-video bg-slate-100 dark:bg-slate-800 rounded-md overflow-hidden relative">
              {source.images && source.images.length > 0 ? (
                <img
                  src={source.images[0].image_url || "/placeholder.svg"}
                  alt={source.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="flex items-center justify-center h-full">
                  <Droplet className="h-12 w-12 text-slate-400" />
                </div>
              )}

              <div className="absolute bottom-2 right-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="secondary">
                      View All Photos
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl">
                    <DialogHeader>
                      <DialogTitle>Photos of {source.name}</DialogTitle>
                    </DialogHeader>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                      {source.images && source.images.length > 0 ? (
                        source.images.map((image: any, index: number) => (
                          <div
                            key={index}
                            className="aspect-video bg-slate-100 dark:bg-slate-800 rounded-md overflow-hidden"
                          >
                            <img
                              src={image.image_url || "/placeholder.svg"}
                              alt={`${source.name} - ${index + 1}`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ))
                      ) : (
                        <div className="col-span-3 flex items-center justify-center h-40">
                          <p className="text-muted-foreground">No photos available</p>
                        </div>
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            <div>
              <h3 className="font-medium mb-2">Description</h3>
              <p className="text-sm text-muted-foreground">
                {source.description || "No description available for this water source."}
              </p>
            </div>

            <div>
              <h3 className="font-medium mb-2">Location</h3>
              <div className="flex items-center text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mr-1" />
                <span>
                  Latitude: {source.latitude.toFixed(6)}, Longitude: {source.longitude.toFixed(6)}
                </span>
              </div>
            </div>

            <div>
              <h3 className="font-medium mb-2">Safety Information</h3>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
                  <div
                    className={`h-2.5 rounded-full ${
                      source.safety_score >= 80
                        ? "bg-green-500"
                        : source.safety_score >= 60
                          ? "bg-yellow-500"
                          : source.safety_score >= 40
                            ? "bg-orange-500"
                            : "bg-red-500"
                    }`}
                    style={{ width: `${source.safety_score}%` }}
                  ></div>
                </div>
                <span className="text-sm font-medium">{source.safety_score}%</span>
              </div>

              <div className="text-sm text-muted-foreground">
                {source.safety_score >= 80 ? (
                  <p>This water source is safe for drinking and general use.</p>
                ) : source.safety_score >= 60 ? (
                  <p>This water is moderately safe. Boiling before drinking is recommended.</p>
                ) : source.safety_score >= 40 ? (
                  <p>Use with caution. Not recommended for drinking without treatment.</p>
                ) : (
                  <p className="flex items-center text-red-500">
                    <AlertTriangle className="h-4 w-4 mr-1" />
                    This water is unsafe for consumption. Seek alternative sources.
                  </p>
                )}
              </div>
            </div>

            <div>
              <h3 className="font-medium mb-2">Last Updated</h3>
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="h-4 w-4 mr-1" />
                <span>
                  {new Date(source.updated_at).toLocaleDateString()} at{" "}
                  {new Date(source.updated_at).toLocaleTimeString()}
                </span>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="quality" className="space-y-4">
            {source.quality ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {getQualityIndicator("pH Level", source.quality.ph_level, "", [6.5, 8.5])}
                  {getQualityIndicator("TDS", source.quality.tds_level, "ppm", [0, 500])}
                  {getQualityIndicator("Turbidity", source.quality.turbidity, "NTU", [0, 5])}
                  {getQualityIndicator("Temperature", source.quality.temperature, "°C", [10, 25])}
                </div>

                <div>
                  <h3 className="font-medium mb-2">Color & Odor</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-2 border rounded-md">
                      <p className="text-sm font-medium">Color</p>
                      <p className="text-sm text-muted-foreground">{source.quality.color || "Not recorded"}</p>
                    </div>
                    <div className="p-2 border rounded-md">
                      <p className="text-sm font-medium">Odor</p>
                      <p className="text-sm text-muted-foreground">{source.quality.odor || "Not recorded"}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Flow Rate</h3>
                  <div className="p-2 border rounded-md">
                    <p className="text-sm">
                      {source.quality.flow_rate ? `${source.quality.flow_rate} L/min` : "Flow rate not measured"}
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Last Measured</h3>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>
                      {new Date(source.quality.measured_at).toLocaleDateString()} at{" "}
                      {new Date(source.quality.measured_at).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <Droplet className="h-12 w-12 mx-auto text-slate-400 mb-2" />
                <h3 className="font-medium">No Quality Data Available</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Water quality measurements have not been recorded for this source yet.
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <div className="text-center py-8">
              <h3 className="font-medium">Community Reports</h3>
              <p className="text-sm text-muted-foreground mt-1">
                No reports have been submitted for this water source yet.
              </p>
              <Button className="mt-4" asChild>
                <Link href={`/public/report?source=${source.id}`}>Submit a Report</Link>
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>

      <CardFooter className="flex justify-between p-4 pt-0">
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <ThumbsUp className="h-4 w-4 mr-1" />
            Helpful
          </Button>
          <Button variant="outline" size="sm">
            <Flag className="h-4 w-4 mr-1" />
            Report Issue
          </Button>
        </div>
        <Button variant="outline" size="sm">
          <Share2 className="h-4 w-4 mr-1" />
          Share
        </Button>
      </CardFooter>
    </Card>
  )
}
