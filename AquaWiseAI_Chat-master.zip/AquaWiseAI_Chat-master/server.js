require("dotenv").config();
const express = require("express");
const bodyParser = require("body-parser");
const admin = require("firebase-admin");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const path = require("path");

// Initialize Firebase
const serviceAccount = require(process.env.FIREBASE_SERVICE_ACCOUNT_PATH);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://aquawise-o7hpk-default-rtdb.firebaseio.com/",
});

const db = admin.database();

// Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const model = genAI.getGenerativeModel({
  model: "gemini-1.5-pro-latest",
  systemInstruction: `You are a smart assistant designed to analyze household water usage data and give personalized recommendations to help reduce consumption and improve efficiency.
  
  The data provided contains time intervals and the corresponding amount of water used (in liters) in each time slot across a full day. The time intervals are represented as 'Time from' and 'Time to' with a corresponding 'Water Used (in liters)' value.
  
  Your job is to:
  - Identify time periods with high water usage based on the 'Water Used (in liters)' value.
  - Suggest ways to reduce water consumption during those periods.
  - Highlight patterns like unusual usage at night or inefficiencies.
  - Recommend actions like rescheduling usage, fixing leaks, or using water-saving appliances.
  - Keep your suggestions friendly, insightful, and actionable.
  
  Here is a sample data format:
  
  [
    {"Time from": "04:30:00", "Time to": "09:30:00", "Water Used (in liters)": 10.20},
    {"Time from": "05:00:00", "Time to": "10:30:00", "Water Used (in liters)": 9.80},
    {"Time from": "23:30:00", "Time to": "00:00:00", "Water Used (in liters)": 0.20}
  ]
  
  Always conclude your response with a positive conservation tip.`,
});

const generationConfig = {
  temperature: 1,
  topP: 0.95,
  topK: 64,
  maxOutputTokens: 65536,
  responseMimeType: "text/plain",
};

// Initialize Express
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Get data from Firebase
async function getWaterUsageData() {
  const ref = db.ref("1YFNfXZi2mTn_CoHeThko2Rb6WBCp2aWdz0_g1pQVmbI/Sheet1"); //https://aquawise-o7hpk-default-rtdb.firebaseio.com/1YFNfXZi2mTn_CoHeThko2Rb6WBCp2aWdz0_g1pQVmbI/Sheet1
  const snapshot = await ref.once("value");
  const rawData = snapshot.val();

  if (!rawData) return [];

  const dataArray = Object.values(rawData);

  dataArray.sort((a, b) => {
    const timeA = a["Time from"].split(":").map(Number);
    const timeB = b["Time from"].split(":").map(Number);

    if (timeA[0] !== timeB[0]) return timeA[0] - timeB[0];
    if (timeA[1] !== timeB[1]) return timeA[1] - timeB[1];
    return timeA[2] - timeB[2];
  });

  
  return dataArray;
}

// Chat endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;
    const waterData = await getWaterUsageData();

    if (!message) {
      return res.status(400).json({ success: false, error: "Message is required." });
    }

    const chatSession = model.startChat({ generationConfig });
    const userInput = `Water usage data:\n${JSON.stringify(waterData, null, 2)}\n\nUser Message: ${message}`;
    const result = await chatSession.sendMessage(userInput);

    res.json({ success: true, response: result.response.text() });
  } catch (error) {
    console.error("Chat error:", error);
    res.status(500).json({ success: false, error: "Chat failed" });
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});


// Change the host to '0.0.0.0' to make it accessible on the local network
app.listen(port, '0.0.0.0', () => {
   console.log(`Server running on http://192.168.1.5:${port}`);
 });
 
// Export for Vercel
//module.exports = app;
//module.exports.handler = serverless(app);