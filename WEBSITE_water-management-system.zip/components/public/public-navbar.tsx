"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { DropletIcon, Menu, X, Moon, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTheme } from "next-themes"

export function PublicNavbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()
  const { theme, setTheme } = useTheme()

  const isActive = (path: string) => {
    return pathname === path
  }

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/public" className="flex items-center gap-2">
            <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-md">
              <DropletIcon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold">WaterSense</h2>
              <p className="text-xs text-muted-foreground hidden sm:block">Clean Water for All</p>
            </div>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/public"
            className={`text-sm font-medium transition-colors hover:text-blue-600 dark:hover:text-blue-400 ${
              isActive("/public") ? "text-blue-600 dark:text-blue-400" : "text-foreground"
            }`}
          >
            Home
          </Link>
          <Link
            href="/public/map"
            className={`text-sm font-medium transition-colors hover:text-blue-600 dark:hover:text-blue-400 ${
              isActive("/public/map") ? "text-blue-600 dark:text-blue-400" : "text-foreground"
            }`}
          >
            Find Water
          </Link>
          <Link
            href="/public/report"
            className={`text-sm font-medium transition-colors hover:text-blue-600 dark:hover:text-blue-400 ${
              isActive("/public/report") ? "text-blue-600 dark:text-blue-400" : "text-foreground"
            }`}
          >
            Report
          </Link>
          <Link
            href="/public/education"
            className={`text-sm font-medium transition-colors hover:text-blue-600 dark:hover:text-blue-400 ${
              isActive("/public/education") ? "text-blue-600 dark:text-blue-400" : "text-foreground"
            }`}
          >
            Education
          </Link>
          <Link
            href="/public/community"
            className={`text-sm font-medium transition-colors hover:text-blue-600 dark:hover:text-blue-400 ${
              isActive("/public/community") ? "text-blue-600 dark:text-blue-400" : "text-foreground"
            }`}
          >
            Community
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="mr-2">
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          <Button asChild className="hidden md:flex">
            <Link href="/auth/login">Sign In</Link>
          </Button>
          <Button variant="outline" size="icon" onClick={toggleMenu} className="md:hidden">
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden border-t">
          <div className="container py-4 flex flex-col gap-4">
            <Link
              href="/public"
              className={`px-4 py-2 rounded-md ${
                isActive("/public")
                  ? "bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400"
                  : "hover:bg-muted"
              }`}
              onClick={toggleMenu}
            >
              Home
            </Link>
            <Link
              href="/public/map"
              className={`px-4 py-2 rounded-md ${
                isActive("/public/map")
                  ? "bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400"
                  : "hover:bg-muted"
              }`}
              onClick={toggleMenu}
            >
              Find Water
            </Link>
            <Link
              href="/public/report"
              className={`px-4 py-2 rounded-md ${
                isActive("/public/report")
                  ? "bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400"
                  : "hover:bg-muted"
              }`}
              onClick={toggleMenu}
            >
              Report
            </Link>
            <Link
              href="/public/education"
              className={`px-4 py-2 rounded-md ${
                isActive("/public/education")
                  ? "bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400"
                  : "hover:bg-muted"
              }`}
              onClick={toggleMenu}
            >
              Education
            </Link>
            <Link
              href="/public/community"
              className={`px-4 py-2 rounded-md ${
                isActive("/public/community")
                  ? "bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400"
                  : "hover:bg-muted"
              }`}
              onClick={toggleMenu}
            >
              Community
            </Link>
            <Button asChild className="mt-2">
              <Link href="/auth/login" onClick={toggleMenu}>
                Sign In
              </Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  )
}
