import Link from "next/link"
import { DropletIcon, Facebook, Instagram, Twitter } from "lucide-react"

export function PublicFooter() {
  return (
    <footer className="bg-slate-100 dark:bg-slate-900 border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-md">
                <DropletIcon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h2 className="text-lg font-bold">WaterSense</h2>
                <p className="text-xs text-muted-foreground">Clean Water for All</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Helping communities find, report, and maintain clean water sources through technology and collaboration.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/public"
                  className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Home
                </Link>
              </li>
              <li>
                <Link
                  href="/public/map"
                  className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Find Water
                </Link>
              </li>
              <li>
                <Link
                  href="/public/report"
                  className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Report a Source
                </Link>
              </li>
              <li>
                <Link
                  href="/public/education"
                  className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Water Education
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4">Community</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/public/community"
                  className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Volunteer
                </Link>
              </li>
              <li>
                <Link
                  href="/public/community#partners"
                  className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Partner NGOs
                </Link>
              </li>
              <li>
                <Link
                  href="/public/community#leaderboard"
                  className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Leaderboard
                </Link>
              </li>
              <li>
                <Link
                  href="/public/community#events"
                  className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Events
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="text-sm text-muted-foreground">
                <strong>Email:</strong> water-wise@watersense.org
              </li>
              <li className="text-sm text-muted-foreground">
                <strong>Phone:</strong> +8122586514
              </li>
              <li className="text-sm text-muted-foreground">
                <strong>Address:</strong> 123 Kanchipuram, Tamil Nadu, India
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">© 2025 WaterSense. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link
              href="/privacy"
              className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400"
            >
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-sm text-muted-foreground hover:text-blue-600 dark:hover:text-blue-400">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
