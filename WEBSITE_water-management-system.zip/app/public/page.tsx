import Link from "next/link"
import { Button } from "@/components/ui/button"
import { DropletsIcon as WaterDropIcon, MapPinIcon, ShieldCheckIcon, UsersIcon } from "lucide-react"

export default function PublicHomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-blue-50 to-white dark:from-slate-900 dark:to-slate-800 py-20 md:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex-1 space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold tracking-tighter text-blue-600 dark:text-blue-400">
                Clean Water for Everyone
              </h1>
              <p className="text-xl text-slate-700 dark:text-slate-300 max-w-xl">
                Find safe water sources near you, report issues, and join our community effort to ensure clean water
                access for all.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" asChild className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Link href="/public/map">Find Water Nearby</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/public/report">Report a Water Source</Link>
                </Button>
                    <Button size="lg" variant="outline" asChild>
                  <Link href="https://water-quality-model-47rb.onrender.com/">Water-Wise Prediction</Link>
                </Button>
              </div>
            </div>
            <div className="flex-1 relative">
              <div className="relative w-full h-[300px] md:h-[400px] rounded-lg overflow-hidden shadow-xl">
                <div className="absolute inset-0 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                  <WaterDropIcon className="h-32 w-32 text-blue-500/50 dark:text-blue-400/50" />
                </div>
                <img
                  src="https://www.cleanipedia.com/images/v2/30d3a2641a569617f0f971b10911447a-3600w-2400h.jpg"
                  alt="Clean water source"
                  className="absolute inset-0 w-full h-full object-cover rounded-lg opacity-80"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white dark:bg-slate-800">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-900 dark:text-white">
            How Our Platform Helps
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-blue-50 dark:bg-slate-700 p-6 rounded-lg shadow-md">
              <div className="bg-blue-100 dark:bg-blue-900/50 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <MapPinIcon className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-bold mb-2 text-slate-900 dark:text-white">Locate Water Sources</h3>
              <p className="text-slate-700 dark:text-slate-300">
                Find nearby water sources on our interactive map, with details on quality, accessibility, and more.
              </p>
            </div>
            <div className="bg-blue-50 dark:bg-slate-700 p-6 rounded-lg shadow-md">
              <div className="bg-blue-100 dark:bg-blue-900/50 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <ShieldCheckIcon className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-bold mb-2 text-slate-900 dark:text-white">Check Water Quality</h3>
              <p className="text-slate-700 dark:text-slate-300">
                Get real-time data on water quality indicators, safety scores, and usage recommendations.
              </p>
            </div>
            <div className="bg-blue-50 dark:bg-slate-700 p-6 rounded-lg shadow-md">
              <div className="bg-blue-100 dark:bg-blue-900/50 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4">
                <UsersIcon className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-bold mb-2 text-slate-900 dark:text-white">Community Participation</h3>
              <p className="text-slate-700 dark:text-slate-300">
                Report issues, add new sources, and join our network of volunteers working to improve water access.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-blue-50 dark:bg-slate-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-4xl font-bold text-blue-600 dark:text-blue-400">500+</p>
              <p className="text-slate-700 dark:text-slate-300">Water Sources</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-blue-600 dark:text-blue-400">10k+</p>
              <p className="text-slate-700 dark:text-slate-300">Users</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-blue-600 dark:text-blue-400">50+</p>
              <p className="text-slate-700 dark:text-slate-300">Communities</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-blue-600 dark:text-blue-400">200+</p>
              <p className="text-slate-700 dark:text-slate-300">Volunteers</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white dark:bg-slate-800">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold mb-4 text-slate-900 dark:text-white">Join Our Mission</h2>
          <p className="text-xl text-slate-700 dark:text-slate-300 max-w-2xl mx-auto mb-8">
            Help us ensure everyone has access to clean, safe water by contributing to our platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="bg-blue-600 hover:bg-blue-700 text-white">
              <Link href="/public/map">Find Water Sources</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/public/community">Become a Volunteer</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
