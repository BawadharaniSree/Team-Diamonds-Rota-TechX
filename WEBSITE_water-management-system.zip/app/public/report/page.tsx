"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { MapPin, Upload, AlertTriangle } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/components/ui/use-toast"

const sourceFormSchema = z.object({
  name: z.string().min(3, { message: "Name must be at least 3 characters" }),
  source_type: z.string().min(1, { message: "Please select a source type" }),
  description: z.string().optional(),
  is_paid: z.boolean().default(false),
  cost_details: z.string().optional(),
  latitude: z.number().or(z.string().transform((v) => Number.parseFloat(v))),
  longitude: z.number().or(z.string().transform((v) => Number.parseFloat(v))),
  color: z.string().optional(),
  odor: z.string().optional(),
  ph_level: z
    .number()
    .optional()
    .or(z.string().transform((v) => (v ? Number.parseFloat(v) : undefined))),
  turbidity: z
    .number()
    .optional()
    .or(z.string().transform((v) => (v ? Number.parseFloat(v) : undefined))),
  tds_level: z
    .number()
    .optional()
    .or(z.string().transform((v) => (v ? Number.parseInt(v) : undefined))),
  flow_rate: z
    .number()
    .optional()
    .or(z.string().transform((v) => (v ? Number.parseFloat(v) : undefined))),
})

const reportFormSchema = z.object({
  source_id: z.string().uuid(),
  report_type: z.string().min(1, { message: "Please select a report type" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  severity: z.number().or(z.string().transform((v) => Number.parseInt(v))),
})

export default function ReportPage() {
  const [activeTab, setActiveTab] = useState("new-source")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null)
  const router = useRouter()
  const searchParams = useSearchParams()
  const sourceId = searchParams.get("source")
  const { toast } = useToast()
  const supabase = getSupabaseClient()

  const sourceForm = useForm<z.infer<typeof sourceFormSchema>>({
    resolver: zodResolver(sourceFormSchema),
    defaultValues: {
      name: "",
      source_type: "",
      description: "",
      is_paid: false,
      cost_details: "",
      latitude: 12.9716, // Default to a location in your region
      longitude: 77.5946, // Default to a location in your region
      color: "",
      odor: "",
    },
  })

  const reportForm = useForm<z.infer<typeof reportFormSchema>>({
    resolver: zodResolver(reportFormSchema),
    defaultValues: {
      source_id: sourceId || "",
      report_type: "",
      description: "",
      severity: 3,
    },
  })

  const getUserLocation = () => {
    if (navigator.geolocation) {
      try {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords
            setUserLocation({ latitude, longitude })
            sourceForm.setValue("latitude", latitude)
            sourceForm.setValue("longitude", longitude)
            toast({
              title: "Location Detected",
              description: `Coordinates: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
            })
          },
          (error) => {
            console.error("Error getting location:", error)
            // More informative error message based on error code
            let errorMessage = "Unable to access your location. "

            if (error.code === 1) {
              errorMessage += "Location permission was denied. Please enter coordinates manually."
            } else if (error.code === 2) {
              errorMessage += "Location information is unavailable. Please enter coordinates manually."
            } else if (error.code === 3) {
              errorMessage += "Location request timed out. Please enter coordinates manually."
            } else {
              errorMessage += "Please enter coordinates manually or try again later."
            }

            toast({
              title: "Location Access Issue",
              description: errorMessage,
              variant: "destructive",
            })
          },
          { timeout: 10000, enableHighAccuracy: false },
        )
      } catch (error) {
        console.error("Geolocation error:", error)
        toast({
          title: "Location Service Error",
          description: "There was an error accessing location services. Please enter coordinates manually.",
          variant: "destructive",
        })
      }
    } else {
      toast({
        title: "Geolocation Not Supported",
        description: "Your browser doesn't support geolocation. Please enter coordinates manually.",
        variant: "destructive",
      })
    }
  }

  const onSourceSubmit = async (data: z.infer<typeof sourceFormSchema>) => {
    setIsSubmitting(true)
    try {
      // Insert the water source
      const { data: sourceData, error: sourceError } = await supabase
        .from("public_water_sources")
        .insert({
          name: data.name,
          source_type: data.source_type,
          description: data.description,
          is_paid: data.is_paid,
          cost_details: data.cost_details,
          latitude: data.latitude,
          longitude: data.longitude,
          safety_score: 50, // Default score until verified
          verified: false,
        })
        .select()

      if (sourceError) throw sourceError

      const sourceId = sourceData[0].id

      // Insert water quality data if provided
      if (data.color || data.odor || data.ph_level || data.turbidity || data.tds_level || data.flow_rate) {
        const { error: qualityError } = await supabase.from("public_water_quality").insert({
          source_id: sourceId,
          color: data.color,
          odor: data.odor,
          ph_level: data.ph_level,
          turbidity: data.turbidity,
          tds_level: data.tds_level,
          flow_rate: data.flow_rate,
        })

        if (qualityError) console.error("Error inserting quality data:", qualityError)
      }

      toast({
        title: "Water Source Added",
        description: "Thank you for contributing to our database!",
      })

      router.push(`/public/map?source=${sourceId}`)
    } catch (error) {
      console.error("Error submitting water source:", error)
      toast({
        title: "Submission Failed",
        description: "An error occurred while adding the water source. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const onReportSubmit = async (data: z.infer<typeof reportFormSchema>) => {
    setIsSubmitting(true)
    try {
      const { error } = await supabase.from("public_water_reports").insert({
        source_id: data.source_id,
        report_type: data.report_type,
        description: data.description,
        severity: data.severity,
        status: "pending",
      })

      if (error) throw error

      toast({
        title: "Report Submitted",
        description: "Thank you for your report. Our team will review it shortly.",
      })

      router.push(`/public/map?source=${data.source_id}`)
    } catch (error) {
      console.error("Error submitting report:", error)
      toast({
        title: "Submission Failed",
        description: "An error occurred while submitting your report. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Contribute to Water Data</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="new-source">Add New Water Source</TabsTrigger>
          <TabsTrigger value="report-issue" disabled={!sourceId && activeTab !== "report-issue"}>
            Report an Issue
          </TabsTrigger>
        </TabsList>

        <TabsContent value="new-source">
          <Card>
            <CardHeader>
              <CardTitle>Add a New Water Source</CardTitle>
              <CardDescription>
                Help others by adding a water source you've discovered. Your contribution makes a difference!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...sourceForm}>
                <form onSubmit={sourceForm.handleSubmit(onSourceSubmit)} className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Basic Information</h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={sourceForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Source Name</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Central Park Lake" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={sourceForm.control}
                        name="source_type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Source Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select source type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="lake">Lake</SelectItem>
                                <SelectItem value="tank">Tank</SelectItem>
                                <SelectItem value="borewell">Borewell</SelectItem>
                                <SelectItem value="river">River</SelectItem>
                                <SelectItem value="tap">Tap</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={sourceForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Provide details about this water source..."
                              className="min-h-[100px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                      <div>
                        <FormField
                          control={sourceForm.control}
                          name="is_paid"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                              <div className="space-y-0.5">
                                <FormLabel>Paid Source</FormLabel>
                                <FormDescription>Does this water source require payment?</FormDescription>
                              </div>
                              <FormControl>
                                <Switch checked={field.value} onCheckedChange={field.onChange} />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>

                      {sourceForm.watch("is_paid") && (
                        <FormField
                          control={sourceForm.control}
                          name="cost_details"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Cost Details</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., ₹5 per liter" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Location</h3>

                    <div className="flex flex-col space-y-4">
                      <div className="flex items-center gap-2">
                        <Button type="button" variant="outline" onClick={getUserLocation}>
                          <MapPin className="h-4 w-4 mr-2" />
                          Try to Use My Location
                        </Button>
                        {userLocation && <p className="text-sm text-green-600">Location detected successfully</p>}
                      </div>

                      <div className="bg-muted/50 p-3 rounded-md text-sm">
                        <p>
                          <strong>Note:</strong> Location detection may not work in all browsers or environments. If
                          automatic detection fails, please enter the coordinates manually below.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={sourceForm.control}
                          name="latitude"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Latitude</FormLabel>
                              <FormControl>
                                <Input type="number" step="any" {...field} />
                              </FormControl>
                              <FormDescription>Enter a value between -90 and 90</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={sourceForm.control}
                          name="longitude"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Longitude</FormLabel>
                              <FormControl>
                                <Input type="number" step="any" {...field} />
                              </FormControl>
                              <FormDescription>Enter a value between -180 and 180</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Water Quality (Optional)</h3>
                    <p className="text-sm text-muted-foreground">
                      If you have any information about the water quality, please provide it below.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={sourceForm.control}
                        name="color"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Color</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Clear, Brownish" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={sourceForm.control}
                        name="odor"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Odor</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., None, Chlorine" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={sourceForm.control}
                        name="ph_level"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>pH Level (if known)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.1" placeholder="e.g., 7.0" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={sourceForm.control}
                        name="turbidity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Turbidity (NTU)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.1" placeholder="e.g., 1.5" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={sourceForm.control}
                        name="tds_level"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>TDS Level (ppm)</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="e.g., 150" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={sourceForm.control}
                        name="flow_rate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Flow Rate (L/min)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.1" placeholder="e.g., 2.5" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Photos</h3>
                    <div className="border-2 border-dashed rounded-lg p-6 text-center">
                      <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm font-medium">Upload Photos</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Drag and drop or click to upload (Coming soon)
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? "Submitting..." : "Submit Water Source"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="report-issue">
          <Card>
            <CardHeader>
              <CardTitle>Report an Issue</CardTitle>
              <CardDescription>
                Report problems with a water source such as contamination, low availability, or incorrect information.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...reportForm}>
                <form onSubmit={reportForm.handleSubmit(onReportSubmit)} className="space-y-6">
                  <FormField
                    control={reportForm.control}
                    name="source_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Water Source ID</FormLabel>
                        <FormControl>
                          <Input {...field} disabled={!!sourceId} />
                        </FormControl>
                        <FormDescription>
                          {sourceId ? "Water source selected from map" : "Enter the ID of the water source"}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={reportForm.control}
                    name="report_type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Issue Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select issue type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="contamination">Contamination</SelectItem>
                            <SelectItem value="low_availability">Low Availability</SelectItem>
                            <SelectItem value="no_access">No Access</SelectItem>
                            <SelectItem value="incorrect_info">Incorrect Information</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={reportForm.control}
                    name="severity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Severity</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={(value) => field.onChange(Number.parseInt(value))}
                            defaultValue={field.value.toString()}
                            className="flex space-x-2"
                          >
                            <FormItem className="flex items-center space-x-1 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="1" />
                              </FormControl>
                              <FormLabel className="font-normal">Low</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-1 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="2" />
                              </FormControl>
                              <FormLabel className="font-normal">Medium-Low</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-1 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="3" />
                              </FormControl>
                              <FormLabel className="font-normal">Medium</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-1 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="4" />
                              </FormControl>
                              <FormLabel className="font-normal">High</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-1 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="5" />
                              </FormControl>
                              <FormLabel className="font-normal">Critical</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={reportForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe the issue in detail..."
                            className="min-h-[150px]"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="border-2 border-dashed rounded-lg p-6 text-center">
                    <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm font-medium">Upload Photos of the Issue</p>
                    <p className="text-xs text-muted-foreground mt-1">Drag and drop or click to upload (Coming soon)</p>
                  </div>

                  <div className="flex items-center p-3 rounded-md bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-900">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 dark:text-yellow-500 mr-2 flex-shrink-0" />
                    <p className="text-sm text-yellow-800 dark:text-yellow-400">
                      Your report will be reviewed by our team. Critical issues will be prioritized.
                    </p>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? "Submitting..." : "Submit Report"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
